"""Small, typed ctypes facade for the native session store.

The public CAD objects never expose an OCC pointer.  They carry a session-scoped
integer handle, which leaves room for a future in-process OCCT binding without
changing the Python API.
"""

from __future__ import annotations

import ctypes as C
import operator
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence


class NativeError(RuntimeError):
    """Raised when the C++ backend rejects an operation."""


class _SurfaceFaceMetrics(C.Structure):
    _fields_ = [
        ("area", C.c_double),
        ("centroid", C.c_double * 3),
        ("normal", C.c_double * 3),
        ("bbox", C.c_double * 6),
        ("mean_curvature", C.c_double),
        ("gaussian_curvature", C.c_double),
        ("principal_curvature_min", C.c_double),
        ("principal_curvature_max", C.c_double),
        ("surface_geometry", C.c_int),
        ("valid", C.c_int),
    ]


class _SurfacePairMetrics(C.Structure):
    _fields_ = [
        ("face_a", _SurfaceFaceMetrics),
        ("face_b", _SurfaceFaceMetrics),
        ("closest_a", C.c_double * 3),
        ("closest_b", C.c_double * 3),
        ("minimum_distance", C.c_double),
        ("normal_dot", C.c_double),
        ("signed_normal_gap", C.c_double),
        ("tangential_offset", C.c_double),
    ]


_SURFACE_GEOMETRY = {
    0: "other", 1: "plane", 2: "cylinder", 3: "cone", 4: "sphere",
    5: "torus", 6: "bspline", 7: "bezier",
}


def _surface_face_metrics_dict(value: _SurfaceFaceMetrics) -> dict[str, object]:
    return {
        "area": float(value.area),
        "centroid": tuple(float(item) for item in value.centroid),
        "normal": tuple(float(item) for item in value.normal),
        "bbox": tuple(float(item) for item in value.bbox),
        "mean_curvature": float(value.mean_curvature),
        "gaussian_curvature": float(value.gaussian_curvature),
        "principal_curvature_min": float(value.principal_curvature_min),
        "principal_curvature_max": float(value.principal_curvature_max),
        "surface_geometry": _SURFACE_GEOMETRY.get(int(value.surface_geometry), "other"),
        "valid": bool(value.valid),
    }


def _surface_pair_metrics_dict(value: _SurfacePairMetrics) -> dict[str, object]:
    return {
        "face_a": _surface_face_metrics_dict(value.face_a),
        "face_b": _surface_face_metrics_dict(value.face_b),
        "closest_a": tuple(float(item) for item in value.closest_a),
        "closest_b": tuple(float(item) for item in value.closest_b),
        "minimum_distance": float(value.minimum_distance),
        "normal_dot": float(value.normal_dot),
        "signed_normal_gap": float(value.signed_normal_gap),
        "tangential_offset": float(value.tangential_offset),
    }


def _surface_grid(
    points: Sequence[Sequence[Sequence[float]]],
) -> tuple[int, int, list[float]]:
    rows = [list(row) for row in points]
    if len(rows) < 2:
        raise NativeError("surface point grid requires at least two rows")
    columns = len(rows[0])
    if columns < 2 or any(len(row) != columns for row in rows):
        raise NativeError("surface point grid must be rectangular and at least 2 by 2")
    flat: list[float] = []
    for row in rows:
        for point in row:
            if len(point) != 3:
                raise NativeError("surface points must contain three coordinates")
            flat.extend(float(value) for value in point)
    return len(rows), columns, flat


def _subshape_indices(
    indices: Sequence[int] | None,
) -> tuple[C.Array[C.c_size_t] | None, int]:
    """Validate and materialize a zero-based subshape index array."""
    if indices is None:
        values: list[int] = []
    else:
        values = []
        try:
            iterator = iter(indices)
        except TypeError as error:
            raise NativeError("subshape indices must be a sequence of integers") from error
        for index in iterator:
            if isinstance(index, bool):
                raise NativeError("subshape indices must be integers")
            try:
                value = operator.index(index)
            except TypeError as error:
                raise NativeError("subshape indices must be integers") from error
            if value < 0:
                raise NativeError("subshape indices must be non-negative")
            values.append(value)
    if len(set(values)) != len(values):
        raise NativeError("subshape indices must be unique")
    if not values:
        return None, 0
    try:
        return (C.c_size_t * len(values))(*values), len(values)
    except OverflowError as error:
        raise NativeError("subshape index exceeds the platform size limit") from error


def _u64_array(values: Sequence[int], name: str) -> tuple[C.Array[C.c_ulonglong], int]:
    if not values:
        raise NativeError(f"{name} must not be empty")
    try:
        normalized = [operator.index(value) for value in values]
    except TypeError as error:
        raise NativeError(f"{name} must contain integers") from error
    if any(value <= 0 for value in normalized):
        raise NativeError(f"{name} must contain positive handles")
    return (C.c_ulonglong * len(normalized))(*normalized), len(normalized)


def _library_candidates() -> Iterable[Path]:
    explicit = os.environ.get("CADFLOW_CORE_LIBRARY")
    if explicit:
        yield Path(explicit)
    package_dir = Path(__file__).resolve().parent
    yield package_dir / "libcadflow_core.so"
    yield package_dir / "cadflow_core.dll"
    yield package_dir / "libcadflow_core.dylib"
    root = Path(__file__).resolve().parents[2]
    yield root / "build" / "native" / "libcadflow_core.so"
    yield root / "build-fallback" / "native" / "libcadflow_core.so"
    yield root / "build" / "native" / "cadflow_core.dll"
    yield root / "build" / "native" / "libcadflow_core.dylib"


def _load_library() -> C.CDLL:
    for candidate in _library_candidates():
        if candidate.exists():
            return C.CDLL(str(candidate))
    paths = ", ".join(str(path) for path in _library_candidates())
    raise NativeError(f"cadflow native library was not found; tried: {paths}")


def _configure(lib: C.CDLL) -> None:
    handle = C.c_void_p
    u64 = C.c_ulonglong
    f64 = C.c_double
    lib.cadflow_session_create.restype = handle
    lib.cadflow_session_destroy.argtypes = [handle]
    lib.cadflow_surface_face_metrics.argtypes = [
        handle, u64, C.POINTER(_SurfaceFaceMetrics)
    ]
    lib.cadflow_surface_face_metrics.restype = C.c_int
    lib.cadflow_surface_pair_metrics.argtypes = [
        handle, u64, u64, C.POINTER(_SurfacePairMetrics)
    ]
    lib.cadflow_surface_pair_metrics.restype = C.c_int
    for name, args in {
        "cadflow_box": [handle, f64, f64, f64],
        "cadflow_cylinder": [handle, f64, f64],
        "cadflow_sphere": [handle, f64],
        "cadflow_cone": [handle, f64, f64, f64],
        "cadflow_import_step": [handle, C.c_char_p],
        "cadflow_import_brep": [handle, C.c_char_p],
        "cadflow_import_stl": [handle, C.c_char_p],
        "cadflow_polyline": [handle, C.POINTER(f64), C.c_size_t, C.c_int],
        "cadflow_circle_profile": [handle, f64, f64, f64, f64, f64, f64, f64],
        "cadflow_arc": [handle, C.POINTER(f64)],
        "cadflow_interpolate": [handle, C.POINTER(f64), C.c_size_t, C.c_int, f64],
        "cadflow_helix": [handle, f64, f64, f64, f64, f64, f64, f64, f64, f64],
        "cadflow_face": [handle, u64],
        "cadflow_bezier_surface": [
            handle, C.POINTER(f64), C.c_size_t, C.c_size_t, C.POINTER(f64)
        ],
        "cadflow_fit_surface": [
            handle, C.POINTER(f64), C.c_size_t, C.c_size_t, f64, C.c_int, C.c_int
        ],
        "cadflow_extrude": [handle, u64, f64, f64, f64],
        "cadflow_revolve": [handle, u64, f64, f64, f64, f64, f64, f64, f64],
        "cadflow_fillet": [handle, u64, f64, C.POINTER(C.c_size_t), C.c_size_t],
        "cadflow_chamfer": [handle, u64, f64, C.POINTER(C.c_size_t), C.c_size_t],
        "cadflow_shell": [
            handle, u64, f64, C.POINTER(C.c_size_t), C.c_size_t, f64
        ],
        "cadflow_loft": [handle, C.POINTER(u64), C.c_size_t, C.c_int, C.c_int],
        "cadflow_sweep": [handle, u64, u64, C.c_int, C.c_int],
        "cadflow_bspline": [
            handle, C.POINTER(f64), C.c_size_t, C.c_int,
            C.POINTER(f64), C.c_size_t, C.POINTER(C.c_int), C.c_size_t,
            C.POINTER(f64), C.c_int,
        ],
        "cadflow_twisted_sweep": [handle, u64, f64, f64, f64, f64, f64, f64, f64, f64, f64],
        "cadflow_ruled_surface": [handle, u64, u64],
        "cadflow_filling_surface": [handle, C.POINTER(u64), C.c_size_t, f64],
        "cadflow_gordon_surface": [handle, C.POINTER(u64), C.c_size_t, C.POINTER(u64), C.c_size_t, f64],
        "cadflow_sew": [handle, C.POINTER(u64), C.c_size_t, f64],
        "cadflow_shell_to_solid": [handle, u64],
        "cadflow_cut": [handle, u64, u64],
        "cadflow_union": [handle, u64, u64],
        "cadflow_intersect": [handle, u64, u64],
        "cadflow_translate": [handle, u64, f64, f64, f64],
        "cadflow_rotate": [handle, u64, f64, f64, f64, f64, f64, f64, f64],
        "cadflow_mirror": [handle, u64, f64, f64, f64, f64, f64, f64],
        "cadflow_scale": [handle, u64, f64, f64, f64, f64],
        "cadflow_subshape_count": [handle, u64, C.c_int],
        "cadflow_subshape_handles": [handle, u64, C.c_int, C.POINTER(u64), C.c_size_t],
        "cadflow_free_boundary_count": [handle, u64, f64],
        "cadflow_free_boundary_handles": [handle, u64, f64, C.POINTER(u64), C.c_size_t],
        "cadflow_face_properties": [handle, u64, f64, f64, C.POINTER(f64), C.POINTER(f64)],
        "cadflow_volume": [handle, u64],
        "cadflow_area": [handle, u64],
        "cadflow_length": [handle, u64],
        "cadflow_distance": [handle, u64, u64],
        "cadflow_kind": [handle, u64],
        "cadflow_export_step": [handle, u64, C.c_char_p],
        "cadflow_export_dxf": [handle, u64, C.c_char_p, f64],
        "cadflow_export_stl": [handle, u64, C.c_char_p, C.c_int],
        "cadflow_mesh_json": [handle, u64, f64, C.POINTER(C.c_char_p)],
        "cadflow_preview_mesh_buffer": [
            handle,
            u64,
            f64,
            C.POINTER(C.c_char_p),
            C.POINTER(C.c_size_t),
        ],
        "cadflow_execute": [handle, C.c_char_p, C.POINTER(C.c_char_p)],
    }.items():
        getattr(lib, name).argtypes = args
    for name in (
        "cadflow_box", "cadflow_cylinder", "cadflow_sphere", "cadflow_cone",
        "cadflow_import_step",
        "cadflow_import_brep", "cadflow_import_stl",
        "cadflow_polyline", "cadflow_circle_profile", "cadflow_face",
        "cadflow_bezier_surface", "cadflow_fit_surface",
        "cadflow_arc", "cadflow_interpolate",
        "cadflow_helix",
        "cadflow_extrude", "cadflow_revolve",
        "cadflow_fillet", "cadflow_chamfer", "cadflow_shell",
        "cadflow_loft",
        "cadflow_sweep",
        "cadflow_bspline", "cadflow_twisted_sweep", "cadflow_ruled_surface",
        "cadflow_filling_surface", "cadflow_gordon_surface", "cadflow_sew",
        "cadflow_shell_to_solid",
        "cadflow_cut", "cadflow_union", "cadflow_intersect", "cadflow_translate",
        "cadflow_rotate", "cadflow_mirror", "cadflow_scale",
    ):
        getattr(lib, name).restype = u64
    for name in ("cadflow_volume", "cadflow_area", "cadflow_length", "cadflow_distance"):
        getattr(lib, name).restype = f64
    for name in (
        "cadflow_subshape_count", "cadflow_subshape_handles",
        "cadflow_free_boundary_count", "cadflow_free_boundary_handles",
    ):
        getattr(lib, name).restype = C.c_size_t
    lib.cadflow_face_properties.restype = C.c_int
    lib.cadflow_kind.restype = C.c_char_p
    lib.cadflow_export_step.restype = C.c_int
    lib.cadflow_export_dxf.restype = C.c_int
    lib.cadflow_export_stl.restype = C.c_int
    lib.cadflow_mesh_json.restype = C.c_int
    lib.cadflow_preview_mesh_buffer.restype = C.c_int
    lib.cadflow_bbox.argtypes = [handle, u64, C.POINTER(f64)]
    lib.cadflow_bbox.restype = C.c_int
    lib.cadflow_center_of_mass.argtypes = [handle, u64, C.POINTER(f64)]
    lib.cadflow_center_of_mass.restype = C.c_int
    lib.cadflow_topology_counts.argtypes = [handle, u64, C.POINTER(u64)]
    lib.cadflow_topology_counts.restype = C.c_int
    lib.cadflow_execute.restype = C.c_int
    lib.cadflow_free_string.argtypes = [C.c_char_p]
    lib.cadflow_last_error.restype = C.c_char_p
    lib.cadflow_version.restype = C.c_char_p


@dataclass(frozen=True)
class ShapeHandle:
    """An opaque, session-owned native shape reference."""

    session_token: int
    value: int


class NativeSession:
    """Owns native shapes and exposes batched primitive operations."""

    def __init__(self) -> None:
        self._lib = _load_library()
        _configure(self._lib)
        raw = self._lib.cadflow_session_create()
        if not raw:
            raise NativeError(self._error())
        self._raw = raw
        self._token = id(self)
        self._closed = False

    def _error(self) -> str:
        value = self._lib.cadflow_last_error()
        return value.decode("utf-8", "replace") if value is not None else ""

    def _ensure_open(self) -> None:
        if self._closed:
            raise NativeError("native session is closed")

    def _check(self) -> None:
        error = self._error()
        if error:
            raise NativeError(error)

    def _handle(self, value: int) -> ShapeHandle:
        self._ensure_open()
        self._check()
        if not value:
            raise NativeError("native operation returned a null shape handle")
        return ShapeHandle(self._token, int(value))

    def _id(self, shape: ShapeHandle) -> int:
        self._ensure_open()
        if shape.session_token != self._token:
            raise NativeError("shape handle belongs to another session")
        return shape.value

    def box(self, width: float, depth: float, height: float) -> ShapeHandle:
        self._ensure_open()
        return self._handle(self._lib.cadflow_box(self._raw, width, depth, height))

    def cylinder(self, radius: float, height: float) -> ShapeHandle:
        self._ensure_open()
        return self._handle(self._lib.cadflow_cylinder(self._raw, radius, height))

    def sphere(self, radius: float) -> ShapeHandle:
        self._ensure_open()
        return self._handle(self._lib.cadflow_sphere(self._raw, radius))

    def cone(self, radius1: float, radius2: float, height: float) -> ShapeHandle:
        self._ensure_open()
        return self._handle(self._lib.cadflow_cone(self._raw, radius1, radius2, height))

    def import_step(self, path: str | os.PathLike[str]) -> ShapeHandle:
        self._ensure_open()
        return self._handle(
            self._lib.cadflow_import_step(self._raw, os.fspath(path).encode("utf-8"))
        )

    def import_brep(self, path: str | os.PathLike[str]) -> ShapeHandle:
        self._ensure_open()
        return self._handle(
            self._lib.cadflow_import_brep(self._raw, os.fspath(path).encode("utf-8"))
        )

    def import_stl(self, path: str | os.PathLike[str]) -> ShapeHandle:
        self._ensure_open()
        return self._handle(
            self._lib.cadflow_import_stl(self._raw, os.fspath(path).encode("utf-8"))
        )

    def polyline(
        self,
        points: Sequence[Sequence[float]],
        *,
        closed: bool = False,
    ) -> ShapeHandle:
        self._ensure_open()
        coordinates = [tuple(float(value) for value in point) for point in points]
        if any(len(point) != 3 for point in coordinates):
            raise NativeError("polyline points must contain three coordinates")
        flat = [value for point in coordinates for value in point]
        values = (C.c_double * len(flat))(*flat)
        return self._handle(
            self._lib.cadflow_polyline(self._raw, values, len(coordinates), int(closed))
        )

    def circle_profile(
        self,
        radius: float,
        center: Sequence[float] = (0, 0, 0),
        normal: Sequence[float] = (0, 0, 1),
    ) -> ShapeHandle:
        self._ensure_open()
        if len(center) != 3 or len(normal) != 3:
            raise NativeError("circle center and normal must contain three values")
        return self._handle(
            self._lib.cadflow_circle_profile(
                self._raw, *map(float, center), *map(float, normal), radius
            )
        )

    def arc(self, points: Sequence[Sequence[float]]) -> ShapeHandle:
        self._ensure_open()
        coordinates = [tuple(float(value) for value in point) for point in points]
        if len(coordinates) != 3 or any(len(point) != 3 for point in coordinates):
            raise NativeError("arc requires exactly three 3D points")
        flat = [value for point in coordinates for value in point]
        values = (C.c_double * 9)(*flat)
        return self._handle(self._lib.cadflow_arc(self._raw, values))

    def interpolate(
        self,
        points: Sequence[Sequence[float]],
        *,
        periodic: bool = False,
        tolerance: float = 1e-6,
    ) -> ShapeHandle:
        self._ensure_open()
        coordinates = [tuple(float(value) for value in point) for point in points]
        if any(len(point) != 3 for point in coordinates):
            raise NativeError("interpolation points must contain three coordinates")
        flat = [value for point in coordinates for value in point]
        values = (C.c_double * len(flat))(*flat)
        return self._handle(
            self._lib.cadflow_interpolate(
                self._raw,
                values,
                len(coordinates),
                int(periodic),
                tolerance,
            )
        )

    def helix(
        self,
        pitch: float,
        height: float,
        radius: float,
        center: Sequence[float] = (0, 0, 0),
        direction: Sequence[float] = (0, 0, 1),
    ) -> ShapeHandle:
        self._ensure_open()
        if len(center) != 3 or len(direction) != 3:
            raise NativeError("helix center and direction must contain three values")
        return self._handle(
            self._lib.cadflow_helix(
                self._raw,
                pitch,
                height,
                radius,
                *map(float, center),
                *map(float, direction),
            )
        )

    def face(self, wire: ShapeHandle) -> ShapeHandle:
        return self._handle(self._lib.cadflow_face(self._raw, self._id(wire)))

    def bezier_surface(
        self,
        points: Sequence[Sequence[Sequence[float]]],
        *,
        weights: Sequence[Sequence[float]] | None = None,
    ) -> ShapeHandle:
        self._ensure_open()
        rows, columns, flat = _surface_grid(points)
        point_values = (C.c_double * len(flat))(*flat)
        weight_values = None
        if weights is not None:
            weight_rows = [list(row) for row in weights]
            if len(weight_rows) != rows or any(len(row) != columns for row in weight_rows):
                raise NativeError("Bezier weights must match the point grid")
            flattened_weights = [float(value) for row in weight_rows for value in row]
            weight_values = (C.c_double * len(flattened_weights))(*flattened_weights)
        return self._handle(
            self._lib.cadflow_bezier_surface(
                self._raw, point_values, rows, columns, weight_values
            )
        )

    def fit_surface(
        self,
        points: Sequence[Sequence[Sequence[float]]],
        *,
        tolerance: float = 1e-3,
        degree_min: int = 3,
        degree_max: int = 8,
    ) -> ShapeHandle:
        self._ensure_open()
        rows, columns, flat = _surface_grid(points)
        point_values = (C.c_double * len(flat))(*flat)
        return self._handle(
            self._lib.cadflow_fit_surface(
                self._raw,
                point_values,
                rows,
                columns,
                tolerance,
                degree_min,
                degree_max,
            )
        )

    def extrude(self, profile: ShapeHandle, x: float, y: float, z: float) -> ShapeHandle:
        return self._handle(
            self._lib.cadflow_extrude(self._raw, self._id(profile), x, y, z)
        )

    def revolve(
        self,
        profile: ShapeHandle,
        origin: Sequence[float],
        axis: Sequence[float],
        degrees: float = 360.0,
    ) -> ShapeHandle:
        if len(origin) != 3 or len(axis) != 3:
            raise NativeError("revolve origin and axis must contain three values")
        return self._handle(
            self._lib.cadflow_revolve(
                self._raw, self._id(profile), *origin, *axis, degrees
            )
        )

    def fillet(
        self,
        shape: ShapeHandle,
        radius: float,
        edge_indices: Sequence[int] | None = None,
        *,
        edges: Sequence[int] | None = None,
    ) -> ShapeHandle:
        if edge_indices is not None and edges is not None:
            raise NativeError("provide either edge_indices or edges, not both")
        selected = edge_indices if edge_indices is not None else edges
        values, count = _subshape_indices(selected)
        return self._handle(
            self._lib.cadflow_fillet(
                self._raw, self._id(shape), float(radius), values, count
            )
        )

    def chamfer(
        self,
        shape: ShapeHandle,
        distance: float,
        edge_indices: Sequence[int] | None = None,
        *,
        edges: Sequence[int] | None = None,
    ) -> ShapeHandle:
        if edge_indices is not None and edges is not None:
            raise NativeError("provide either edge_indices or edges, not both")
        selected = edge_indices if edge_indices is not None else edges
        values, count = _subshape_indices(selected)
        return self._handle(
            self._lib.cadflow_chamfer(
                self._raw, self._id(shape), float(distance), values, count
            )
        )

    def shell(
        self,
        shape: ShapeHandle,
        thickness: float,
        face_indices: Sequence[int] | None = None,
        *,
        tolerance: float = 1e-3,
        faces: Sequence[int] | None = None,
    ) -> ShapeHandle:
        if faces is not None:
            if face_indices is not None:
                raise NativeError("provide either face_indices or faces, not both")
            face_indices = faces
        values, count = _subshape_indices(face_indices)
        return self._handle(
            self._lib.cadflow_shell(
                self._raw,
                self._id(shape),
                float(thickness),
                values,
                count,
                float(tolerance),
            )
        )

    def loft(
        self,
        profiles: Sequence[ShapeHandle],
        *,
        solid: bool = True,
        ruled: bool = False,
    ) -> ShapeHandle:
        profile_ids = [self._id(profile) for profile in profiles]
        values = (C.c_ulonglong * len(profile_ids))(*profile_ids)
        return self._handle(
            self._lib.cadflow_loft(
                self._raw, values, len(profile_ids), int(solid), int(ruled)
            )
        )

    def sweep(
        self,
        profile: ShapeHandle,
        path: ShapeHandle,
        *,
        solid: bool = True,
        frenet: bool = False,
    ) -> ShapeHandle:
        return self._handle(
            self._lib.cadflow_sweep(
                self._raw,
                self._id(profile),
                self._id(path),
                int(solid),
                int(frenet),
            )
        )

    def bspline(
        self,
        control_points: Sequence[Sequence[float]],
        *,
        degree: int,
        knots: Sequence[float],
        multiplicities: Sequence[int],
        weights: Sequence[float] | None = None,
        periodic: bool = False,
    ) -> ShapeHandle:
        self._ensure_open()
        coordinates = [tuple(float(value) for value in point) for point in control_points]
        if any(len(point) != 3 for point in coordinates):
            raise NativeError("B-spline control points must contain three coordinates")
        flat = [value for point in coordinates for value in point]
        poles = (C.c_double * len(flat))(*flat)
        knot_values = (C.c_double * len(knots))(*[float(value) for value in knots])
        mult_values = (C.c_int * len(multiplicities))(*[int(value) for value in multiplicities])
        weight_values = None if weights is None else (C.c_double * len(weights))(*[float(value) for value in weights])
        return self._handle(self._lib.cadflow_bspline(
            self._raw, poles, len(coordinates), int(degree), knot_values, len(knots),
            mult_values, len(multiplicities), weight_values, int(periodic)))

    def twisted_sweep(
        self,
        profile: ShapeHandle,
        distance: float,
        twist_degrees: float,
        *,
        origin: Sequence[float] = (0, 0, 0),
        axis: Sequence[float] = (0, 0, 1),
        guide_radius: float = 1.0,
    ) -> ShapeHandle:
        if len(origin) != 3 or len(axis) != 3:
            raise NativeError("twisted sweep origin and axis must contain three values")
        return self._handle(self._lib.cadflow_twisted_sweep(
            self._raw, self._id(profile), distance, twist_degrees,
            *map(float, origin), *map(float, axis), guide_radius))

    def ruled_surface(self, edge_a: ShapeHandle, edge_b: ShapeHandle) -> ShapeHandle:
        return self._handle(self._lib.cadflow_ruled_surface(
            self._raw, self._id(edge_a), self._id(edge_b)))

    def filling_surface(self, edges: Sequence[ShapeHandle], *, tolerance: float = 1e-6) -> ShapeHandle:
        values, count = _u64_array([self._id(edge) for edge in edges], "filling edges")
        return self._handle(self._lib.cadflow_filling_surface(self._raw, values, count, tolerance))

    def gordon_surface(
        self,
        profiles: Sequence[ShapeHandle],
        guides: Sequence[ShapeHandle],
        *,
        tolerance: float = 1e-6,
    ) -> ShapeHandle:
        profile_values, profile_count = _u64_array([self._id(value) for value in profiles], "Gordon profiles")
        guide_values, guide_count = _u64_array([self._id(value) for value in guides], "Gordon guides")
        return self._handle(self._lib.cadflow_gordon_surface(
            self._raw, profile_values, profile_count, guide_values, guide_count, tolerance))

    def sew(self, faces: Sequence[ShapeHandle], *, tolerance: float = 1e-6) -> ShapeHandle:
        values, count = _u64_array([self._id(face) for face in faces], "sewing faces")
        return self._handle(self._lib.cadflow_sew(self._raw, values, count, tolerance))

    def shell_to_solid(self, shell: ShapeHandle) -> ShapeHandle:
        return self._handle(self._lib.cadflow_shell_to_solid(self._raw, self._id(shell)))

    def cut(self, body: ShapeHandle, tool: ShapeHandle) -> ShapeHandle:
        return self._handle(self._lib.cadflow_cut(self._raw, self._id(body), self._id(tool)))

    def union(self, left: ShapeHandle, right: ShapeHandle) -> ShapeHandle:
        return self._handle(self._lib.cadflow_union(self._raw, self._id(left), self._id(right)))

    def intersect(self, left: ShapeHandle, right: ShapeHandle) -> ShapeHandle:
        return self._handle(self._lib.cadflow_intersect(self._raw, self._id(left), self._id(right)))

    def translate(self, shape: ShapeHandle, x: float, y: float, z: float) -> ShapeHandle:
        return self._handle(self._lib.cadflow_translate(self._raw, self._id(shape), x, y, z))

    def rotate(
        self,
        shape: ShapeHandle,
        origin: Sequence[float],
        axis: Sequence[float],
        degrees: float,
    ) -> ShapeHandle:
        if len(origin) != 3 or len(axis) != 3:
            raise NativeError("rotation origin and axis must contain three values")
        return self._handle(
            self._lib.cadflow_rotate(self._raw, self._id(shape), *origin, *axis, degrees)
        )

    def mirror(
        self,
        shape: ShapeHandle,
        origin: Sequence[float],
        normal: Sequence[float],
    ) -> ShapeHandle:
        if len(origin) != 3 or len(normal) != 3:
            raise NativeError("mirror origin and normal must contain three values")
        return self._handle(
            self._lib.cadflow_mirror(self._raw, self._id(shape), *origin, *normal)
        )

    def scale(
        self,
        shape: ShapeHandle,
        factor: float,
        center: Sequence[float] = (0, 0, 0),
    ) -> ShapeHandle:
        if len(center) != 3:
            raise NativeError("scale center must contain three values")
        return self._handle(
            self._lib.cadflow_scale(self._raw, self._id(shape), *center, factor)
        )

    def volume(self, shape: ShapeHandle) -> float:
        value = float(self._lib.cadflow_volume(self._raw, self._id(shape)))
        self._check()
        return value

    def area(self, shape: ShapeHandle) -> float:
        value = float(self._lib.cadflow_area(self._raw, self._id(shape)))
        self._check()
        return value

    def length(self, shape: ShapeHandle) -> float:
        value = float(self._lib.cadflow_length(self._raw, self._id(shape)))
        self._check()
        return value

    def distance(self, left: ShapeHandle, right: ShapeHandle) -> float:
        value = float(
            self._lib.cadflow_distance(self._raw, self._id(left), self._id(right))
        )
        self._check()
        return value

    def center_of_mass(self, shape: ShapeHandle) -> tuple[float, float, float]:
        output = (C.c_double * 3)()
        ok = self._lib.cadflow_center_of_mass(self._raw, self._id(shape), output)
        self._check()
        if not ok:
            raise NativeError("native center-of-mass query failed")
        return tuple(float(item) for item in output)  # type: ignore[return-value]

    def bbox(self, shape: ShapeHandle) -> tuple[float, float, float, float, float, float]:
        output = (C.c_double * 6)()
        ok = self._lib.cadflow_bbox(self._raw, self._id(shape), output)
        self._check()
        if not ok:
            raise NativeError("native bounding-box query failed")
        return tuple(float(item) for item in output)  # type: ignore[return-value]

    def topology(self, shape: ShapeHandle) -> dict[str, int]:
        output = (C.c_ulonglong * 4)()
        ok = self._lib.cadflow_topology_counts(self._raw, self._id(shape), output)
        self._check()
        if not ok:
            raise NativeError("native topology query failed")
        return dict(zip(("vertices", "edges", "faces", "solids"), map(int, output)))

    def subshapes(self, shape: ShapeHandle, shape_type: int) -> tuple[ShapeHandle, ...]:
        self._ensure_open()
        count = int(self._lib.cadflow_subshape_count(self._raw, self._id(shape), int(shape_type)))
        self._check()
        if not count:
            return ()
        values = (C.c_ulonglong * count)()
        returned = int(self._lib.cadflow_subshape_handles(
            self._raw, self._id(shape), int(shape_type), values, count))
        self._check()
        if returned != count:
            raise NativeError("native subshape count changed during extraction")
        return tuple(self._handle(value) for value in values)

    def free_boundaries(self, shape: ShapeHandle, *, tolerance: float = 1e-6) -> tuple[ShapeHandle, ...]:
        self._ensure_open()
        count = int(self._lib.cadflow_free_boundary_count(self._raw, self._id(shape), tolerance))
        self._check()
        if not count:
            return ()
        values = (C.c_ulonglong * count)()
        returned = int(self._lib.cadflow_free_boundary_handles(
            self._raw, self._id(shape), tolerance, values, count))
        self._check()
        if returned != count:
            raise NativeError("native free-boundary count changed during extraction")
        return tuple(self._handle(value) for value in values)

    def face_properties(self, face: ShapeHandle, *, u: float = 0.5, v: float = 0.5) -> dict[str, tuple[float, ...]]:
        normal = (C.c_double * 3)()
        curvature = (C.c_double * 3)()
        ok = self._lib.cadflow_face_properties(
            self._raw, self._id(face), u, v, normal, curvature)
        self._check()
        if not ok:
            raise NativeError("native face property query failed")
        return {
            "normal": tuple(float(value) for value in normal),
            "curvature": tuple(float(value) for value in curvature),
        }

    def surface_face_metrics(self, face: ShapeHandle) -> dict[str, object]:
        """Return solver-neutral geometric evidence for one BREP face."""
        self._ensure_open()
        output = _SurfaceFaceMetrics()
        ok = self._lib.cadflow_surface_face_metrics(
            self._raw, self._id(face), C.byref(output)
        )
        self._check()
        if not ok:
            raise NativeError("native surface face measurement failed")
        return _surface_face_metrics_dict(output)

    def surface_pair_metrics(
        self, face_a: ShapeHandle, face_b: ShapeHandle
    ) -> dict[str, object]:
        """Return exact closest-point and orientation evidence for two faces."""
        self._ensure_open()
        output = _SurfacePairMetrics()
        ok = self._lib.cadflow_surface_pair_metrics(
            self._raw, self._id(face_a), self._id(face_b), C.byref(output)
        )
        self._check()
        if not ok:
            raise NativeError("native surface pair measurement failed")
        return _surface_pair_metrics_dict(output)

    def kind(self, shape: ShapeHandle) -> str:
        value = self._lib.cadflow_kind(self._raw, self._id(shape))
        self._check()
        return value.decode("ascii") if value else "unknown"

    def export_step(self, shape: ShapeHandle, path: str | os.PathLike[str]) -> None:
        ok = self._lib.cadflow_export_step(self._raw, self._id(shape), os.fspath(path).encode("utf-8"))
        self._check()
        if not ok:
            raise NativeError("native STEP export failed")

    def export_dxf(
        self,
        face: ShapeHandle,
        path: str | os.PathLike[str],
        *,
        tolerance: float = 0.01,
    ) -> None:
        ok = self._lib.cadflow_export_dxf(
            self._raw,
            self._id(face),
            os.fspath(path).encode("utf-8"),
            float(tolerance),
        )
        self._check()
        if not ok:
            raise NativeError("native DXF profile export failed")

    def export_stl(
        self,
        shape: ShapeHandle,
        path: str | os.PathLike[str],
        *,
        binary: bool = True,
    ) -> None:
        ok = self._lib.cadflow_export_stl(
            self._raw,
            self._id(shape),
            os.fspath(path).encode("utf-8"),
            int(binary),
        )
        self._check()
        if not ok:
            raise NativeError("native STL export failed")

    def mesh(self, shape: ShapeHandle, deflection: float = 0.1) -> dict[str, list[float] | list[int]]:
        import json

        result = C.c_char_p()
        ok = self._lib.cadflow_mesh_json(self._raw, self._id(shape), deflection, C.byref(result))
        self._check()
        if not ok or not result.value:
            raise NativeError("native mesh generation failed")
        try:
            return json.loads(result.value.decode("utf-8"))
        finally:
            self._lib.cadflow_free_string(result)

    def preview_mesh_buffer(
        self, shape: ShapeHandle, deflection: float = 0.35
    ) -> bytes:
        """Return the versioned native render buffer without JSON conversion."""
        result = C.c_char_p()
        size = C.c_size_t()
        ok = self._lib.cadflow_preview_mesh_buffer(
            self._raw,
            self._id(shape),
            deflection,
            C.byref(result),
            C.byref(size),
        )
        self._check()
        if not ok or not result or size.value == 0:
            raise NativeError("native preview mesh generation failed")
        try:
            return C.string_at(result, size.value)
        finally:
            self._lib.cadflow_free_string(result)

    def execute(self, program: str) -> list[str]:
        self._ensure_open()
        result = C.c_char_p()
        ok = self._lib.cadflow_execute(self._raw, program.encode("utf-8"), C.byref(result))
        self._check()
        if not ok or not result.value:
            raise NativeError("native graph execution returned no result")
        try:
            return result.value.decode("utf-8").splitlines()
        finally:
            self._lib.cadflow_free_string(result)

    @property
    def version(self) -> str:
        self._ensure_open()
        return self._lib.cadflow_version().decode("ascii")

    def close(self) -> None:
        if not self._closed:
            self._lib.cadflow_session_destroy(self._raw)
            self._closed = True

    def __enter__(self) -> "NativeSession":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def __del__(self) -> None:  # pragma: no cover - interpreter shutdown path
        try:
            self.close()
        except Exception:
            pass
