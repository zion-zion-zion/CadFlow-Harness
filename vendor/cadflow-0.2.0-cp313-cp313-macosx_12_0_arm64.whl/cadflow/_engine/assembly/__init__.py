"""Product and assembly modeling."""
